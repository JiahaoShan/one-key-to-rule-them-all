var searchData=
[
  ['next_5fpage_5fnumber',['next_page_number',['../classbadgerdb_1_1_page.html#a8050c219873e6b1d51aec2adbea8a507',1,'badgerdb::Page']]],
  ['nosuchkeyfoundexception',['NoSuchKeyFoundException',['../classbadgerdb_1_1_no_such_key_found_exception.html#a3a0244d27d3212414ec3e8c309f1357d',1,'badgerdb::NoSuchKeyFoundException']]]
];
