var searchData=
[
  ['readpage',['readPage',['../classbadgerdb_1_1_buf_mgr.html#a9f853f0f1d4628e7e14374d0c7c6a4f3',1,'badgerdb::BufMgr::readPage()'],['../classbadgerdb_1_1_file.html#aba4762b533499b7b7cc0774192ead27c',1,'badgerdb::File::readPage()']]],
  ['record_5fid',['record_id',['../classbadgerdb_1_1_invalid_record_exception.html#a7cac504679cb65e114552cf6480e0151',1,'badgerdb::InvalidRecordException']]],
  ['record_5fid_5f',['record_id_',['../classbadgerdb_1_1_invalid_record_exception.html#af1a2e1ad376303aa5411b7d168634586',1,'badgerdb::InvalidRecordException']]],
  ['recordid',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]],
  ['refbit',['refbit',['../classbadgerdb_1_1_bad_buffer_exception.html#af871746d373d9a16e2203a783e06d00e',1,'badgerdb::BadBufferException']]],
  ['remove',['remove',['../classbadgerdb_1_1_buf_hash_tbl.html#a5739cc2b22c74d62e25c9d3d316144d8',1,'badgerdb::BufHashTbl::remove()'],['../classbadgerdb_1_1_file.html#a1cc69467366badbd68021ac76a91190e',1,'badgerdb::File::remove()']]]
];
