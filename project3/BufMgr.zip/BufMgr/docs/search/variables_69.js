var searchData=
[
  ['invalid_5fnumber',['INVALID_NUMBER',['../classbadgerdb_1_1_page.html#a785a1e756d47fb7f8f3603a3fe8ffcef',1,'badgerdb::Page']]],
  ['invalid_5fslot',['INVALID_SLOT',['../classbadgerdb_1_1_page.html#a4013fab43df72bc52931241575736353',1,'badgerdb::Page']]],
  ['item_5flength',['item_length',['../structbadgerdb_1_1_page_slot.html#a675118fb03cd9e1b35970a1f10bda9d8',1,'badgerdb::PageSlot']]],
  ['item_5foffset',['item_offset',['../structbadgerdb_1_1_page_slot.html#a81c14b0e942b0d59e6ac31667d958b79',1,'badgerdb::PageSlot']]]
];
