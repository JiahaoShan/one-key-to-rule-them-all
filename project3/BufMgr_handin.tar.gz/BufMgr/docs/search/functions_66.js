var searchData=
[
  ['file',['File',['../classbadgerdb_1_1_file.html#a600baaf77d18f39e51ae7473eca633c4',1,'badgerdb::File']]],
  ['fileexistsexception',['FileExistsException',['../classbadgerdb_1_1_file_exists_exception.html#a127fc62de579ee20359d50aad560e60e',1,'badgerdb::FileExistsException']]],
  ['fileiterator',['FileIterator',['../classbadgerdb_1_1_file_iterator.html#a99bd5c0e0fac0493f9664409219ca88e',1,'badgerdb::FileIterator::FileIterator()'],['../classbadgerdb_1_1_file_iterator.html#ad286fc916be769b1bea154603b83ece0',1,'badgerdb::FileIterator::FileIterator(File *file)'],['../classbadgerdb_1_1_file_iterator.html#afabd7eecd315a85f9eb602f71c6f88e3',1,'badgerdb::FileIterator::FileIterator(File *file, PageId page_number)']]],
  ['filename',['filename',['../classbadgerdb_1_1_file_exists_exception.html#ae130ffc5272c27418eb04ab727c2ed72',1,'badgerdb::FileExistsException::filename()'],['../classbadgerdb_1_1_file_not_found_exception.html#adce2194e38bd4b975a6771e6b07e7be2',1,'badgerdb::FileNotFoundException::filename()'],['../classbadgerdb_1_1_file_open_exception.html#adcda987e33c390531d8eebdb222a7762',1,'badgerdb::FileOpenException::filename()'],['../classbadgerdb_1_1_invalid_page_exception.html#a5283ca7595055156c3f669d49e83446f',1,'badgerdb::InvalidPageException::filename()'],['../classbadgerdb_1_1_file.html#ac61ce3c2233fd1f7e2e2a8a5a7640936',1,'badgerdb::File::filename()']]],
  ['filenotfoundexception',['FileNotFoundException',['../classbadgerdb_1_1_file_not_found_exception.html#a53d52b9ecbd214bb5db7e9b3401248b8',1,'badgerdb::FileNotFoundException']]],
  ['fileopenexception',['FileOpenException',['../classbadgerdb_1_1_file_open_exception.html#af315ef5b756efe579a1b8ee7f6e4d352',1,'badgerdb::FileOpenException']]],
  ['flushfile',['flushFile',['../classbadgerdb_1_1_buf_mgr.html#acc61d1985720411ebb76e70f702827d3',1,'badgerdb::BufMgr']]]
];
