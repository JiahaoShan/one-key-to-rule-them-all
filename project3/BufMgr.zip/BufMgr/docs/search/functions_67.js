var searchData=
[
  ['getbufstats',['getBufStats',['../classbadgerdb_1_1_buf_mgr.html#a93148e1af99f06f4f264d948920b7c1c',1,'badgerdb::BufMgr']]],
  ['getfreespace',['getFreeSpace',['../classbadgerdb_1_1_page.html#af3d324b5aae656030465e213e86e2070',1,'badgerdb::Page']]],
  ['getnextusedslot',['getNextUsedSlot',['../classbadgerdb_1_1_page_iterator.html#a7b5eb61bcd7305f0aaa21e0f31d2f917',1,'badgerdb::PageIterator']]],
  ['getrecord',['getRecord',['../classbadgerdb_1_1_page.html#a77b352920c3e66384317bbcdcd900d99',1,'badgerdb::Page']]]
];
